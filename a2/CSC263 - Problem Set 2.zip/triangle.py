'''
CSC263 Winter 2020
Problem Set 2 Starter Code
University of Toronto Mississauga
'''

# Do NOT add any "import" statements
# Do NOT use Python dictionaries

def num_triangle_kinds(triangles):
  '''
  Pre: triangles is a list of 3-tuples representing triangles
  Post: return the number of kinds of triangles
  '''
  pass # TODO: implement this function

if __name__ == '__main__':

  # some small test cases
  # Case 1
  triangles = [(6, 12, 9), (9, 6, 12), (9, 6, 6), (6, 9, 9), (12, 9, 6)]
  assert 3 == num_triangle_kinds(triangles)
